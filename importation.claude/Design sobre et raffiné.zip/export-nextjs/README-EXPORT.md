# Export vers le projet Next.js

Les maquettes de ce projet sont des prototypes HTML : un seul fichier, styles en ligne,
état géré à la main. Votre site est un projet Next.js avec Tailwind v4, des composants
typés et vos propres données. Il n'y a donc pas de bouton « exporter » : ce dossier
contient les composants **réécrits en TSX + Tailwind**, aux mêmes chemins que chez vous,
prêts à remplacer les fichiers existants.

## Comment ça se passe

1. **Les couleurs deviennent des tokens.** Le prototype utilisait `var(--fond)`,
   `var(--encre)`, `var(--accent)`… Ces variables sont déclarées dans `globals.css`
   en deux jeux : `:root` (sombre) et `[data-theme="clair"]`. Le bloc `@theme inline`
   les expose à Tailwind, donc vous écrivez `bg-fond`, `text-encre`, `border-filet`
   comme n'importe quelle classe Tailwind.

2. **Le thème est un contexte React.** `ThemeProvider` pose `data-theme` sur `<html>`
   et mémorise le choix dans `localStorage`. Tout le reste suit automatiquement.

3. **Vos données ne changent pas.** `data/prints.ts`, `data/options.ts`,
   `lib/pricing.ts`, `lib/images.ts`, le panier et le tunnel Stripe restent tels quels.
   Les composants ci-dessous consomment vos types existants (`Print`, `CategoryFilter`,
   `SelectOption`).

4. **Les images non plus.** Le prototype dupliquait vos fichiers dans `img/` ;
   en production, `obtenirUrlImageTirage(tirage, cadre, format)` — que vous avez déjà —
   sert l'aperçu encadré, et `obtenirUrlVignetteTirage` la grille.

## Ordre d'installation

| # | Fichier | Action |
|---|---------|--------|
| 1 | `app/globals.css` | remplacer (contient aussi le correctif de police) |
| 2 | `app/layout.tsx` | remplacer |
| 3 | `components/theme/ThemeProvider.tsx` | nouveau |
| 4 | `components/theme/ThemeToggle.tsx` | nouveau |
| 5 | `components/layout/Header.tsx` | remplacer |
| 6 | `components/layout/Footer.tsx` | remplacer |
| 7 | `components/home/HeroSection.tsx` | remplacer |
| 8 | `components/home/CategoryFilterRail.tsx` | nouveau (remplace `CategoryFilterMenu`) |
| 9 | `components/home/GallerySection.tsx` | remplacer |
| 10 | `components/home/PrintCard.tsx` | remplacer |
| 11 | `components/home/AboutSection.tsx` | remplacer |
| 12 | `components/home/ContactSection.tsx` | remplacer |
| 13 | `components/portfolio/PortfolioGrid.tsx` | nouveau |
| 14 | `app/portfolio/page.tsx` | nouveau |
| 15 | `components/print/OptionRow.tsx` | nouveau (remplace `OptionGroup`) |
| 16 | `components/print/PrintDetailModal.tsx` | remplacer |
| 17 | `app/page.tsx` | remplacer |
| 18 | `components/shared/PrintImage.tsx` | 3 lignes à modifier — voir `NOTES-INTEGRATION.md` |

Fichiers devenus inutiles après installation :
`components/home/CategoryFilterMenu.tsx`, `components/print/OptionGroup.tsx`,
`components/cart/CartButton.tsx` (le panier est passé dans l'en-tête).

## Trois correctifs inclus au passage

- **Les polices ne s'appliquaient pas.** `globals.css` forçait
  `font-family: Arial, Helvetica, sans-serif` sur le `body`, ce qui écrasait Geist et
  Playfair chargés dans `layout.tsx`. C'était la principale cause de l'effet
  « pas fini ». Le nouveau `globals.css` utilise `var(--font-geist-sans)`.
- **Le bloc `prefers-color-scheme: dark`** changeait `--background` / `--foreground`,
  que rien ne consommait puisque tout était en classes `stone-*`. Remplacé par le
  vrai système de thème.
- **Le bouton panier flottant** imposait une marge droite artificielle au header
  (`pr-20 sm:pr-36`). Le panier est maintenant dans l'en-tête, le logo peut être centré.

## Ce qui reste à faire de votre côté

- **Le panier et le tunnel de commande.** `CartDrawer`, `CartLine` et les composants
  de `components/checkout/` sont à passer aux tokens : `bg-stone-50` → `bg-fond`,
  `text-stone-900` → `text-encre`, `text-stone-600` → `text-texte`,
  `border-stone-200` → `border-filet`, `bg-stone-900` → `bg-accent` avec
  `text-fond`. C'est une substitution, pas une refonte : je ne les ai pas réécrits
  parce que la logique Stripe qu'ils contiennent n'a aucune raison de bouger, et qu'une
  réécriture ferait courir un risque au tunnel de paiement pour un gain purement
  visuel. Les maquettes du tunnel sont dans les deux prototypes si vous voulez la
  version dessinée.
- **La catégorie « Nocturne »** n'a aucun tirage dans `data/prints.ts`. Le rail de
  filtres l'affiche donc pour un résultat vide. À retirer ou à alimenter.
- **Le fichier hero** est `hero-section-mobile.jpg` dans les deux cas. Si vous avez
  une version desktop, ajoutez un `<source>` ou un second `PrintImage` conditionnel.
