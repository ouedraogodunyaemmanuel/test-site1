import type { CSSProperties } from "react";
import { useRef } from "react";
import type { Print } from "@/types/print";
import { formaterPrixCHF, PRIX_MINIMUM } from "@/lib/pricing";
import { obtenirUrlImageTirage, obtenirUrlVignetteTirage } from "@/lib/images";
import { FORMATS } from "@/data/options";
import { PrintImage } from "@/components/shared/PrintImage";

export function PrintCard({
  tirage,
  onOuvrir,
  style,
  sizes = "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw",
  onRatioConnu,
  animationDelayMs = 0,
  priority = false,
}: {
  tirage: Print;
  onOuvrir: () => void;
  style?: CSSProperties;
  sizes?: string;
  onRatioConnu?: (ratio: number) => void;
  animationDelayMs?: number;
  priority?: boolean;
}) {
  const dejaPrechargee = useRef(false);

  function prechargerImageDetail() {
    if (dejaPrechargee.current) return;
    dejaPrechargee.current = true;
    new window.Image().src = obtenirUrlImageTirage(tirage, "aucun", FORMATS[0].value);
  }

  return (
    <button
      type="button"
      onClick={onOuvrir}
      onMouseEnter={prechargerImageDetail}
      onFocus={prechargerImageDetail}
      className="group gallery-card-enter block text-left transition-transform active:scale-[0.97]"
      style={{ animationDelay: `${animationDelayMs}ms` }}
    >
      <div className="overflow-hidden" style={style}>
        <PrintImage
          src={obtenirUrlVignetteTirage(tirage)}
          alt={tirage.title}
          sizes={sizes}
          dimensionnement="rempli"
          unoptimized
          priority={priority}
          onRatioConnu={onRatioConnu}
          imageClassName="transition-transform duration-700 ease-out group-hover:scale-105"
        />
      </div>

      {/* Titre et prix sous la photo, toujours lisibles. Ils
          n'apparaissaient qu'au survol, donc jamais sur mobile. */}
      <div className="mt-3 flex items-baseline justify-between gap-4">
        <span className="font-serif text-lg text-encre">{tirage.title}</span>
        <span className="text-[11px] tracking-[0.08em] whitespace-nowrap uppercase text-accent">
          dès {formaterPrixCHF(PRIX_MINIMUM)}
        </span>
      </div>
    </button>
  );
}
