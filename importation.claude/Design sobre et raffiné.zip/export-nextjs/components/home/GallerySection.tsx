import type { Print } from "@/types/print";
import type { CategoryFilter, CategoryFilterOption } from "@/types/CategoryFilter";
import { CategoryFilterRail } from "./CategoryFilterRail";
import { JustifiedGallery } from "./JustifiedGallery";

export function GallerySection({
  filtres,
  categorieActive,
  onChangementCategorie,
  tirages,
  onOuvrirTirage,
}: {
  filtres: CategoryFilterOption[];
  categorieActive: CategoryFilter;
  onChangementCategorie: (categorie: CategoryFilter) => void;
  tirages: Print[];
  onOuvrirTirage: (tirage: Print) => void;
}) {
  return (
    // `relative z-10` + fond opaque : la section passe par-dessus la
    // photo du hero, qui est en `sticky` derrière elle.
    <section
      id="gallery"
      className="relative z-10 w-full bg-fond pt-9 pb-24"
    >
      <div className="mx-auto w-full max-w-6xl px-6 sm:px-10">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div className="flex flex-col gap-3.5">
            <span className="h-px w-9 bg-accent sm:w-10" />
            <h2 className="font-serif text-3xl text-encre sm:text-4xl">
              La collection
            </h2>
            <p className="text-sm text-attenue">
              Sept tirages, imprimés à la demande.
            </p>
          </div>
          <CategoryFilterRail
            filtres={filtres}
            categorieActive={categorieActive}
            onChangementCategorie={onChangementCategorie}
          />
        </div>

        <div className="mt-10">
          {tirages.length > 0 ? (
            <JustifiedGallery tirages={tirages} onOuvrirTirage={onOuvrirTirage} />
          ) : (
            <div className="flex flex-col items-center gap-2.5 py-16 text-center">
              <span className="font-serif text-xl text-encre">Aucun tirage</span>
              <span className="text-sm text-attenue">
                Cette catégorie n&apos;a pas encore de tirage. Choisissez-en une autre.
              </span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
