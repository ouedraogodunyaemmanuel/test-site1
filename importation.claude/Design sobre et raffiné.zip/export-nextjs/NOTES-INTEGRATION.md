# Correctif à appliquer à `components/shared/PrintImage.tsx`

Ce composant est le seul que je n'ai pas recopié en entier : ses 269 lignes de
logique (verrouillage du ratio, fondu croisé entre deux variantes, aperçu flou,
plafond `hauteurMaximaleVh`) sont justes et n'ont aucune raison de changer. Seules
**quatre couleurs codées en dur** doivent devenir des tokens de thème, sans quoi la
fiche tirage garde un fond blanc en mode sombre.

## Les quatre remplacements

### 1. Le fond de la boîte, mode « rempli » (≈ ligne 196)

```diff
-        className={`relative h-full w-full overflow-hidden bg-stone-200 ${
+        className={`relative h-full w-full overflow-hidden bg-panneau ${
```

### 2. Le fond de la boîte, mode « auto » (≈ ligne 236)

```diff
       className={`relative w-full overflow-hidden ${
-        ajustement === "contain" ? "bg-white transition-all duration-500 ease-out" : "bg-stone-200"
+        ajustement === "contain" ? "bg-panneau transition-all duration-500 ease-out" : "bg-panneau"
       } ${boiteVide ? "animate-pulse" : ""} ${
```

### 3. Le passe-partout autour de la photo, mode « contain » (≈ ligne 259)

```diff
   if (ajustement === "contain") {
     return (
-      <div className={`flex items-center justify-center bg-white p-4 sm:p-6 ${containerClassName}`}>
+      <div className={`flex items-center justify-center bg-panneau p-4 sm:p-6 ${containerClassName}`}>
         {image}
       </div>
     );
   }
```

### 4. Rien d'autre

`animate-pulse`, les transitions et les `object-cover` / `object-contain` sont
neutres vis-à-vis du thème.

---

# Ce que j'ai découvert en lisant les fichiers, et qui change l'export

Trois écarts entre ce que j'avais supposé et votre code réel. Ils sont **déjà
corrigés** dans les fichiers livrés, mais autant que vous les connaissiez.

## 1. `useCart()` n'expose pas les noms français

Votre contexte expose `itemCount`, `openCart`, `closeCart`, `isOpen`, `totalPrice`,
`addItem`, `removeItem`, `updateQuantity`, `clearCart`, `isReady`. J'avais écrit
`nombreArticles` et `ouvrirPanier` dans le Header — corrigé.

## 2. `Print` n'a pas de `slug`, mais un `imageFolder`

Vos tirages sont identifiés par `id` (1, 2, 3, 5, 6, 9 — la série a des trous) et
leur dossier d'images par `imageFolder` (`/images/tirages/sentinelles`). C'est aussi
la clé de `RATIOS_IMAGES`. Le portfolio construit donc `/?tirage=${tirage.id}`.

## 3. L'aperçu ne varie pas avec le format quand il n'y a pas de cadre

C'est dans `lib/images.ts` :

```ts
if (cadre === "aucun") {
  return `${tirage.imageFolder}/aucun.jpg`;
}
return `${tirage.imageFolder}/${cadre}-${format}.jpg`;
```

Sans cadre, un seul fichier suffit — le rendu d'une photo nue ne dépend pas de sa
taille d'impression. L'aperçu « Chez vous » ne réagit donc au format qu'une fois un
cadre choisi. C'est cohérent, mais si vous voulez que le format compte toujours, il
faut générer des `aucun-20x30.jpg` etc. et lever ce cas particulier.

---

# Ce que la nouvelle modale conserve de la vôtre

J'ai gardé, à l'identique :

- l'animation d'entrée et de sortie avec le minuteur de 200 ms et le démontage confié
  au parent ;
- la touche Échap, qui ferme d'abord la confirmation « sans cadre » puis la fiche ;
- le blocage du défilement de l'arrière-plan, avec restauration de la valeur
  précédente ;
- le verrouillage du ratio sur la première valeur connue, semé depuis
  `RATIOS_IMAGES`, pour que la fiche ne change pas de largeur au fil des clics ;
- l'élargissement de la fiche pour les photos en paysage (`max-w-7xl` / `max-w-5xl`) ;
- la forme exacte de l'objet passé à `addItem`, y compris les libellés lisibles et la
  photo figée aux options du moment de l'ajout ;
- la confirmation « sans cadre », avec présélection du cadre blanc.

## Ce qui change, et pourquoi

- **`OptionGroup` est remplacé par `OptionRow`.** Trois menus dépliants demandaient
  deux taps par choix sur mobile et cachaient ce qui existe. Les options tiennent en
  grilles de boutons toujours visibles, avec des pastilles de couleur pour les cadres.
- **Le préchargement devient global.** Votre logique s'accrochait à l'ouverture d'un
  groupe (`prechargerVariantesDuGroupe`) ; sans menus, ce moment n'existe plus. Les
  neuf combinaisons sont préchargées à l'ouverture de la fiche. Vous pouvez supprimer
  `components/print/OptionGroup.tsx` et le type `OptionGroupName`.
- **Deux images au lieu d'une.** La photo du haut est la vue nue et ne bouge jamais ;
  c'est le bloc « Chez vous » qui suit les options. Sur votre version, l'unique photo
  changeait à chaque clic, ce qui faisait perdre la référence.
- **La barre prix + « Ajouter » est collée en bas.** Le bouton « Fermer » disparaît :
  la croix, le clic sur le fond et Échap suffisent, et la place sert au prix.


---

# Le passage entre vue mobile et vue desktop

Il n'y a **pas deux maquettes** dans le code livré : un seul jeu de composants, avec
des points de rupture Tailwind. Les deux prototypes de ce projet sont figés à 390 px
et 1440 px pour être lisibles côte à côte, mais l'export, lui, est fluide entre les
deux.

## Ce qui bascule, et à quelle largeur

| Élément | < 640 px (`sm`) | ≥ 640 px | ≥ 1024 px (`lg`) |
|---|---|---|---|
| Navigation | menu plein écran, thème dans le menu | idem | nav et bascule de thème dans l'en-tête (`md`) |
| Hero | plein écran, titre 36 px | titre 48 px | titre 60 px |
| Collection | colonne unique | grille justifiée | grille justifiée |
| Filtres | rail défilant horizontal | pastilles qui passent à la ligne | idem |
| Fiche tirage | plein écran, photo à fond perdu | modale centrée, photo sur panneau | modale plus large |
| À propos | photo puis texte | idem | photo à gauche, texte à droite |
| Contact | coordonnées en liste | idem | deux colonnes |
| Portfolio | une colonne | deux colonnes | trois colonnes |

Le rail de filtres utilise `-mx-6 px-6` sous `sm` : le débordement se fait à fond
perdu, sans casser la gouttière de la page.

## Deux défauts corrigés après relecture

### 1. Le hero avait une hauteur de départ codée en dur

`HAUTEUR_MAX = 844` (la hauteur d'un iPhone) servait de point de départ à la
réduction. Sur un écran de bureau à 1080 px, le hero n'occupait donc pas la fenêtre
au chargement ; sur un petit portable à 700 px, il la dépassait. Et un
redimensionnement de la fenêtre ne changeait rien, puisque la constante ne bougeait
pas.

La hauteur de départ est maintenant `window.innerHeight`, relue à chaque
redimensionnement. Deux conséquences :

- **La hauteur de l'en-tête est mesurée**, pas devinée. Elle diffère entre mobile et
  desktop (taille du logo, présence de la bascule de thème), et la marge négative qui
  fait passer la photo dessous doit suivre. Elle est aussi remesurée après
  `document.fonts.ready`, parce que le chargement de Playfair change la hauteur de
  la ligne du logo.
- **Les seuils d'estompage sont proportionnels** à la hauteur de la fenêtre
  (`depart * 0.5` pour le titre, `depart * 0.2` pour l'indicateur) et non plus des
  nombres de pixels absolus, pour que le rythme soit le même partout.

### 2. La fiche tirage n'affichait rien sur desktop

La photo était rendue en `dimensionnement="rempli"` avec
`containerClassName="sm:hidden"`. Cette classe masquait le conteneur au-delà de
640 px : le panneau de gauche restait vide sur desktop. Et le `sm:h-auto` du parent
donnait de toute façon une hauteur nulle, puisque le mode « rempli » exige un parent
de hauteur connue.

Corrigé par deux rendus, un par point de rupture, parce que le cadrage voulu n'est
pas le même :

- **mobile** : `dimensionnement="rempli"` dans une boîte `h-[42vh]` — photo à fond
  perdu, recadrée, avec le fondu vers la page en bas ;
- **desktop** : `ajustement="contain"` avec `hauteurMaximaleVh={70}` — photo
  entière sur son panneau, jamais recadrée, et qui rétrécit sur une fenêtre basse au
  lieu de forcer une barre de défilement.

Même URL dans les deux cas, donc un seul téléchargement.

## Ce qui reste à vérifier chez vous

- **`JustifiedGallery.tsx`** calcule lui-même la boîte en pixels de chaque photo à
  partir de son ratio réel. Je ne l'ai pas touché : il gère déjà le
  redimensionnement. Vérifiez simplement qu'il n'a pas de `bg-stone-*` en dur.
- **Le hero utilise `hero-section-mobile.jpg`** à toutes les largeurs. Le fichier est
  suffisamment grand, mais son cadrage est vertical : sur un écran large, le sujet
  peut être coupé. Si vous avez une version paysage, ajoutez-la en `<source>`.
- **`100dvh` plutôt que `innerHeight`** si la barre d'adresse mobile vous gêne :
  `window.innerHeight` change quand elle se rétracte, ce qui provoque un léger
  soubresaut du hero au premier défilement sur iOS. Remplacer par
  `document.documentElement.clientHeight` supprime l'effet.